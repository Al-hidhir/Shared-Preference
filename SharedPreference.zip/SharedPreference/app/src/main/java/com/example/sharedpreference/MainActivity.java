package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText name;
    EditText pass;
    EditText email;
    SharedPreferences sharedPreferences;
    static final String  myprefrence = "mypref";
    static final String  Name = "nameKey";
    static final String  Pass = "PassKey";
    static final String  Email = "emailKey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = (EditText)findViewById(R.id.name);
        pass = (EditText)findViewById(R.id.pass);
        email = (EditText)findViewById(R.id.mail);

        sharedPreferences = getSharedPreferences(myprefrence, Context.MODE_PRIVATE);
        if (sharedPreferences.contains(Name)){
            name.setText(sharedPreferences.getString(Name, ""));
        }
        if (sharedPreferences.contains(Pass)){
            pass.setText(sharedPreferences.getString(Pass, ""));
        }
        if (sharedPreferences.contains(Email)){
            email.setText(sharedPreferences.getString(Email, ""));
        }
    }

    public void  save(View v){
        String n = name.getText().toString();
        String p = pass.getText().toString();
        String e = email.getText().toString();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(Name, n);
        editor.putString(Pass, p);
        editor.putString(Email, e);
        editor.commit();

    }

    public void clear(View v){
        name.setText("");
        pass.setText("");
        email.setText("");

    }

    public void view(View v){
        sharedPreferences = getSharedPreferences(myprefrence, Context.MODE_PRIVATE);
        if (sharedPreferences.contains(Name)){
            name.setText(sharedPreferences.getString(Name, ""));
    }
        if (sharedPreferences.contains(Pass)){
            pass.setText(sharedPreferences.getString(Pass, ""));
        }
        if (sharedPreferences.contains(Email)){
            email.setText(sharedPreferences.getString(Email, ""));
        }
    }

}
